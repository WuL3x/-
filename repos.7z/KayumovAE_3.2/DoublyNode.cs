﻿namespace KayumovAE_3._2
{
    internal class DoublyNode<T>
    {
    }
}