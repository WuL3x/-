﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Kayumov_4._2
{
    class Program
    {
        public static int[] Bubble(int[] arr)
        {
            int buf;
            for (int i = arr.Length - 1; i > 0; i--)
            {
                for (int j = 0; j < i; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        buf = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = buf;
                    }
                }
            }
            return arr;
        }
        public static void max(int n)
        {
            Queue<int> ocher = new Queue<int>();
            Queue<int> que = new Queue<int>();

            for (int i = 0; i < n; i++)
            {


                Console.Write("Числовое значение № " + (i + 1) + ": ");
                int x = Convert.ToInt32(Console.ReadLine());
                ocher.Enqueue(x);
                if (x == 0)
                {
                    break;
                }
                if (x < 0)
                {
                    que.Enqueue(x);

                }
                
            }
            if (que.Count == 0)
            {
                Console.WriteLine("Нет отрицательных значений!");

            }
            else
            {
                Console.Write("Очередь из отрицательных значений: ");
                foreach (int x in que)
                {
                    Console.Write(x + " ");
                }
                int[] arr = que.ToArray();
                Bubble(arr);
                Console.WriteLine();
                
                Console.WriteLine();
                Console.WriteLine("Наибольшее отрицательное число: " + arr.Last());
                

            }
            que.Clear();
            ocher.Clear();
            
        }

        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Введите количество элементов в числовой последовательности: ");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();

                max(n);

                Console.WriteLine();
                Console.WriteLine("Для нового ввода нажмите Enter \nДля выхода нажмите ESC");
                if (Console.ReadKey().Key == ConsoleKey.Enter)
                {
                    continue;
                }
                if (Console.ReadKey().Key == ConsoleKey.Escape)
                {
                    break;
                }
            }
        }
    }
}

        
    



