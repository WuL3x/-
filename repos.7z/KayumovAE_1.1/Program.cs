﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayumovAE_1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[10];
            {
                for (int i = 0; i < 10; i++)
                {
                    numbers[i] = Convert.ToInt32(Console.ReadLine());
                }
                int buf;
                int k = 10;
                for (int i = k - 1; i > 0; i--)
                    for (int j = 0; j < i; j++)
                        if (numbers[j] > numbers[j + 1])
                        {
                            buf = numbers[j];
                            numbers[j] = numbers[j + 1];
                            numbers[j + 1] = buf;
                        }
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(numbers[i]);
                    Console.Write("; ");
                }
            }
            Console.ReadKey();
        }
    }
}
