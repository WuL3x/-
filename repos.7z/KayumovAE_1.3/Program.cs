﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayumovAE_1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[10];
            {
                for (int i = 0; i < 10; i++)
                {
                    numbers[i] = Convert.ToInt32(Console.ReadLine());
                }
                int min, temp;
                int k = 10;
                for (int i = 0; i < k - 1; i++)
                {
                    min = 1;
                    for (int j = i + 1; j < k; j++)
                    {
                        if (numbers[j] < numbers[min]) min = j;
                    }
                    temp = numbers[i];
                    numbers[i] = numbers[min];
                    numbers[min] = temp;
                }
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(numbers[i]);
                    Console.Write("; ");
                }
            }
            Console.ReadKey();
        }
    }
}
