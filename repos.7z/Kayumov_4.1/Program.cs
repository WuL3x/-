﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Kayumov_4._1
{
    class Program
    {
        public static void prov(string text) // метод для проверки скобок
        {
            var asapstack = new Stack<char>(); // стек для открывающей скобки
            var lilstack = new Stack<char>(); // стек для закрывающей скобки
            Console.Write("Вывод только круглых скобок: ");
            for (int i = 0; i < text.Length; i++) // цикл вывода одних только скобок без текста
            {
                if (text.Contains('(') && text[i] == '(')
                {
                    lilstack.Push('('); // помещаем ( в стек при выполнении условий
                    Console.Write('(');
                }
                if (text.Contains(')') && text[i] == ')')
                {
                    asapstack.Push(')'); // помещаем ) в стек при выполнении условий
                    Console.Write(')');
                }
            }
            Console.WriteLine();
            if (lilstack.Count == asapstack.Count && text.IndexOf('(') < text.IndexOf(')') && text.IndexOf(')') != 0) // проверка на равное количество скобок,
            {                                                                                                         // на расположение открывающийх и закрывающих скобок
                Console.WriteLine();                                                                                  // и на первый элемент текста
                Console.WriteLine("Скобки раставлены верно. Ошибок не замечено.");
                Console.WriteLine("------------");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Ошибка! Проверьте растановку скобок.");
                Console.WriteLine("------------");
            }
            lilstack.Clear(); // очистка стека
            asapstack.Clear(); // очистка стека
        }
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Введите строку, содержащую ( и ): "); // ввод текста
                string text = Console.ReadLine();
                Console.WriteLine();
                prov(text); // вызов метода
                Console.WriteLine();
                Console.WriteLine("Для нового ввода нажмите Enter \nНажмите ESC для выхода"); 
                Console.WriteLine();
                if (Console.ReadKey().Key == ConsoleKey.Enter) // при нажатии на Enter процесс продолжается. При нажатии ESC - прерывается
                {
                    continue;
                }
                if (Console.ReadKey().Key == ConsoleKey.Escape)
                {
                    break;
                }
            }
        }
    }
}

