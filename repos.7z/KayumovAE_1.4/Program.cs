﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    namespace KayumovAE

    {

        class Program

        {

            static void Main(string[] args)
            {
                int[] numbers = new int[10];
                {
                    for (int i = 0; i < 10; i++)
                    {
                        numbers[i] = Convert.ToInt32(Console.ReadLine());
                    }
                    int k = 10;
                    for (int i = 1; i < k; i++)
                    {
                        int cur = numbers[i];
                        int j = i;
                        while (j > 0 && cur < numbers[j - 1])
                        {
                            numbers[j] = numbers[j - 1];
                            j--;
                        }
                        numbers[j] = cur;
                    }
                    for (int i = 0; i < 10; i++)
                    {
                        Console.Write(numbers[i]);
                        Console.Write("; ");
                    }
                }
                Console.ReadKey();
            }
        }
    }

