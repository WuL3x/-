﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayumovAE_2._1
{
    class Program
    {

        struct student // объявление структуры
        {
            public string S_familiya, S_name, S_year, S_byear, S_address, S_zachetka, S_rating;
        }
        static void Main(string[] args)
        {
            Console.Write("Сколько студентов? "); // Количество студентов
            int n = Convert.ToInt32(Console.ReadLine());
            student[] a = new student[n]; // объявление массива из N количества элементов
            for (int i = 0; i < n; i++)
            {
                for (i = 0; i < n; i++) // цикл заполнения
                {
                    Console.WriteLine("Студент № " + (i + 1) + ": ");
                    Console.Write("Фамилия: ");
                    a[i].S_familiya = Console.ReadLine();
                    Console.Write("Имя: ");
                    a[i].S_name = Console.ReadLine();
                    Console.Write("Год поступления: ");
                    a[i].S_year = Console.ReadLine();
                    Console.Write("Год рождения: ");
                    a[i].S_byear = Console.ReadLine();
                    Console.Write("Адрес: ");
                    a[i].S_address = Console.ReadLine();
                    Console.Write("Зачетка: ");
                    a[i].S_zachetka = Console.ReadLine();
                    Console.Write("Рейтинг: ");
                    a[i].S_rating = Console.ReadLine();
                    Console.WriteLine("---------");
                }

                while (true)
                {
                    Console.WriteLine("Вывод " + "'всех' " + "студентов или по фамилии? \nВведите ВСЕХ для вывода всего списка или иной символ для вывода по фамилии");

                    string z = Console.ReadLine();
                    if (z == "всех")
                    {
                        for (i = 0; i < n; i++) // вывод всех студентов
                        {
                            Console.WriteLine("---------");
                            Console.WriteLine("Фамилия: " + a[i].S_familiya);
                            Console.WriteLine("Имя: " + a[i].S_name);
                            Console.WriteLine("Год поступления: " + a[i].S_year);
                            Console.WriteLine("Год рождения: " + a[i].S_byear);
                            Console.WriteLine("Адрес: " + a[i].S_address);
                            Console.WriteLine("Номер зачетки: " + a[i].S_zachetka);
                            Console.WriteLine("Рейтинг: " + a[i].S_rating);
                            Console.WriteLine("---------");
                        }
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите фамилию"); // вывод стеднтов по фамилии

                        string x = Console.ReadLine();

                        for (i = 0; i < n; i++)
                        {
                            if (x == a[i].S_familiya)
                            {
                                Console.WriteLine("------------");
                                Console.WriteLine("Фамилия: " + a[i].S_familiya);
                                Console.WriteLine("Имя: " + a[i].S_name);
                                Console.WriteLine("Год поступления: " + a[i].S_year);
                                Console.WriteLine("Год рождения: " + a[i].S_byear);
                                Console.WriteLine("Адрес: " + a[i].S_address);
                                Console.WriteLine("Номер зачетки: " + a[i].S_zachetka);
                                Console.WriteLine("Рейтинг: " + a[i].S_rating);
                            }
                        }
                    }
                    Console.WriteLine();
                    Console.WriteLine("Закончить работу?");
                    string r = Console.ReadLine();
                    Console.WriteLine();
                    if (r == "да")
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }

            }

            Console.ReadKey();
        }
    }
}


