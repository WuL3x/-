﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayumovAE_1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[10];
            {
                for (int i = 0; i < 10; i++)
                {
                    numbers[i] = Convert.ToInt32(Console.ReadLine());
                }
                int k = 10;
                int t;
                bool exchange;
                do
                {
                    exchange = false;
                    for (int i = k - 1; i > 0; --i)
                    {
                        if (numbers[i - 1] > numbers[i])
                        {
                            t = numbers[i - 1];
                            numbers[i - 1] = numbers[i];
                            numbers[i] = t;
                            exchange = true;
                        }
                    }
                    for (int i = 1; i < k; ++i)
                    {
                        if (numbers[i - 1] > numbers[i])
                        {
                            t = numbers[i - 1];
                            numbers[i - 1] = numbers[i];
                            numbers[i] = t;
                            exchange = true;
                        }
                    }
                }
                while (exchange);
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(numbers[i]);
                    Console.Write("; ");
                }
            }
            Console.ReadKey();
        }
    }
}
