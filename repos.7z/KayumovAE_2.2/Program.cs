﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayumovAE_2._2
{
    class Program
    {

        struct telephone // объявление структуры
        {
            public string T_telephon, T_name, T_familiya, T_adres, T_index;
        }
        static void Main(string[] args)
        {
            Console.Write("Сколько абонентов? "); // Количество абонентов
            int n = Convert.ToInt32(Console.ReadLine());
            telephone[] a = new telephone[n]; // объявление массива из N количества элементов
            for (int i = 0; i < n; i++)
            {
                for (i = 0; i < n; i++) // цикл заполнения
                {
                    Console.WriteLine("Абонент № " + (i + 1) + ": ");
                    Console.Write("Номер телефона: ");
                    a[i].T_telephon = Console.ReadLine();
                    Console.Write("Имя абонента: ");
                    a[i].T_name = Console.ReadLine();
                    Console.Write("Фамилия: ");
                    a[i].T_familiya = Console.ReadLine();
                    Console.Write("Адрес: ");
                    a[i].T_adres = Console.ReadLine();
                    Console.Write("Почтовый индекс: ");
                    a[i].T_index = Console.ReadLine();
                    
                }

                while (true)
                {
                    Console.WriteLine("Вывод " + "'всех' " + "абонентов или по телефону? \nВведите ВСЕХ для вывода всего списка или иной символ для вывода по телефону");

                    string z = Console.ReadLine();
                    if (z == "всех")
                    {
                        for (i = 0; i < n; i++) // вывод всех абонентов
                        {
                            Console.WriteLine("---------");
                            Console.WriteLine("Номер телефона: " + a[i].T_telephon);
                            Console.WriteLine("Имя абонента : " + a[i].T_name);
                            Console.WriteLine("Фамилия : " + a[i].T_familiya);
                            Console.WriteLine("Адрес : " + a[i].T_adres);
                            Console.WriteLine("Почтовый индекс: " + a[i].T_index);
                            Console.WriteLine("---------");
                        }
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите номер абонента"); // вывод абонентов по номеру телефона

                        string x = Console.ReadLine();

                        for (i = 0; i < n; i++) // цикл вывода
                        {
                            if (x == a[i].T_telephon)
                            {
                                Console.WriteLine("------------");
                                Console.WriteLine("Номер телефона: " + a[i].T_telephon);
                                Console.WriteLine("Имя абонента : " + a[i].T_name);
                                Console.WriteLine("Фамилия : " + a[i].T_familiya);
                                Console.WriteLine("Адрес : " + a[i].T_adres);
                                Console.WriteLine("Почтовый индекс: " + a[i].T_index);
                                Console.WriteLine("------------");
                            }
                        }
                    }
                    Console.WriteLine();
                    Console.WriteLine("Закончить работу?");
                    string r = Console.ReadLine();
                    Console.WriteLine();
                    if (r == "да") // если ответ ДА то процесс прерывается
                    {
                        break;
                    }
                    else // Если НЕТ, то продолжатся
                    {
                        continue;
                    }
                }

            }

            Console.ReadKey();
        }
    }
}
